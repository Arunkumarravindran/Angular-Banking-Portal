export class UserVO {
    userName: string;
    password: string;
  }